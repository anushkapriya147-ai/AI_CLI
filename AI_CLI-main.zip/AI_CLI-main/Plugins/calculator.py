from .base import BaseTool

class CalculatorTool(BaseTool):
    name = "calculator"
    description = "Performs basic math calculations."

    def run(self, input_text):
        try:
            return str(eval(input_text))
        except Exception:
            return "Invalid mathematical expression."
