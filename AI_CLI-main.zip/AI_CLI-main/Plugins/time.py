from Plugins.base import BaseTool
from datetime import datetime

class TimeTool(BaseTool):
    name = "time"
    description = "Provides the current date and time."

    def run(self, input_text):
        # You can optionally parse input_text if needed (e.g. timezone)
        now = datetime.now()
        formatted_time = now.strftime("%Y-%m-%d %H:%M:%S")
        return f"Current date and time: {formatted_time}"
