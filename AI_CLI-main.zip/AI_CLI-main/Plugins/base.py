class BaseTool:
    name = "Base"
    description = "Base tool description"

    def run(self, input_text):
        raise NotImplementedError("Tool must implement run()")


