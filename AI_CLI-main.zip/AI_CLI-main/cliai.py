import os
import sys
from groq import Groq
from dotenv import load_dotenv
import json
import importlib

from Plugins.base import BaseTool

# Load API key from .env
load_dotenv()
api_key = os.getenv("GROQ_API_KEY")

if not api_key:
    print("❌ ERROR: GROQ_API_KEY not found in .env file")
    sys.exit(1)

# Initialize Groq client
client = Groq(api_key=api_key)

# ---- MEMORY FOR FULL SESSION ----
memory = []  # store ALL previous messages until quit


def add_to_memory(role, content):
    """Store full conversation history for the session."""
    memory.append({"role": role, "content": content})


print("🤖 AI CLI Agent (Groq LLM)")
print("Type 'exit' or 'quit' to close.\n")


def load_Plugins():
    tools = {}
    plugin_folder = "Plugins"

    for file in os.listdir(plugin_folder):
        if file.endswith(".py") and file not in ["__init__.py", "base.py"]:
            module_name = file.replace(".py", "")
            module = importlib.import_module(f"Plugins.{module_name}")

            for attr in dir(module):
                obj = getattr(module, attr)

                if isinstance(obj, type) and issubclass(obj, BaseTool) and obj is not BaseTool:
                    tool = obj()
                    tools[tool.name] = tool

    return tools


tools = load_Plugins()


def ai_decision(user_input, tools):
    tool_list = ", ".join(tools.keys())

    system_prompt = f"""
You are an AI agent with access to the following tools: {tool_list}

When a user asks about the current time or date, always call the appropriate tool to get accurate information instead of guessing.

If the user provides a location or timezone, pass that as input to the tool, so it can provide the correct local time.

Respond ONLY in the following JSON format:

{{
    "action": "call_tool" or "final_answer",
    "tool": "tool_name_here or empty string",
    "input": "input_for_tool or empty",
    "answer": "if no tool needed"
}}

Example:
If user says: "What time is it in Pune, India?"
Your response should be:

{{
    "action": "call_tool",
    "tool": "time",
    "input": "Pune, India",
    "answer": ""
}}

If user says something that does not require a tool, respond with:

{{
    "action": "final_answer",
    "tool": "",
    "input": "",
    "answer": "Your answer here"
    
    }}
"""

    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_input}
        ]+ memory
    )

    try:
        return json.loads(response.choices[0].message.content)
    except:
        return {"action": "final_answer", "answer": "Error: Invalid JSON."}


# Chat Loop
while True:
    user_input = input("YOU:")

    if user_input.lower() in ["exit", "quit"]:
        print("👋 Goodbye!")
        break

    add_to_memory("user", user_input)

    # Let the AI decide
    decision = ai_decision(user_input, tools)

    if decision["action"] == "call_tool":
        tool_name = decision["tool"]
        tool_input = decision["input"]

        if tool_name in tools:
            tool = tools[tool_name]
            tool_result = tool.run(tool_input)

            add_to_memory("assistant", tool_result)
            print(f"🔧 TOOL ({tool_name}): {tool_result}")
        else:
            print(f"❌ Tool {tool_name} not found")

    else:
        # Final answer from AI
        reply = decision["answer"]
        add_to_memory("assistant", reply)
        print("AI:", reply)





'''
✅ 1.3 Clean Exception Handling

It never crashes even if API fails.

🔧 2.1 Plugin / Tool System

AI chooses a tool when needed.  how does ai do it

🔗 2.2 Dynamic Tool Selection (Like ChatGPT)   how does ai do it


🔒 2.5 Input Sanitization (Security)

Your framework protects:

No shell commands allowed

No access outside project folder

No file deletion unless allowed   I HAVE TO DO IT

'''


'''
CODE T0 RESTRICT ACESS TO ONLY SPECIFIC FOLDER

import os

BASE_DIR = os.path.abspath("./project_folder")

def safe_open(file_path, mode="r"):
    full_path = os.path.abspath(os.path.join(BASE_DIR, file_path))

    # Prevent access outside the base directory
    if not full_path.startswith(BASE_DIR):
        raise PermissionError("❌ Access outside project folder is blocked.")

    return open(full_path, mode)

'''